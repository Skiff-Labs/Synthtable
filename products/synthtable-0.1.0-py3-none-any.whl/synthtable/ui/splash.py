import os
import platform

from pyfiglet import Figlet
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


console = Console()


def get_logo() -> Text:
    """
    Build the Synthtable terminal logo.
    """

    figlet = Figlet(font="standard")

    wordmark = figlet.renderText("Synthtable").rstrip()

    logo = Text(wordmark, style="bold green")

    return logo


def get_system_info() -> Table:
    """
    Build the system information panel.
    """

    table = Table.grid(padding=(0, 4))

    table.add_column(style="green")
    table.add_column(style="white")
    table.add_column(style="green")
    table.add_column(style="white")

    terminal = os.environ.get("TERM", "unknown")

    table.add_row(
        "✓ Synthtable CLI",
        f"v{__import__('synthtable').__version__}",
        "✓ Platform",
        platform.system(),
    )

    table.add_row(
        "✓ Python",
        platform.python_version(),
        "✓ Terminal",
        terminal,
    )

    return table


def get_quick_start() -> Table:
    """
    Build the quick-start commands panel.
    """

    table = Table.grid(padding=(0, 2))

    table.add_column(style="bold green", width=26)
    table.add_column(style="white")

    table.add_row(
            "synthtable init",
            "Initialize SeedForge in your project before use.",
    )

    table.add_row(
        "synthtable generate",
        "Generate seed data for your database",
    )

    table.add_row(
        "synthtable inspect",
        "Inspect",
    )

    table.add_row(
        "synthtable preview",
        "Preview",
    )

    table.add_row(
        "synthtable --help",
        "Show all available commands",
    )

    return table


def print_splash() -> None:
    """
    Render the Synthtable startup screen.
    """

    console.clear()

    # Logo
    console.print(get_logo(), justify="center")

    # Tagline
    console.print(
        Text(
            "Your schema, populated.",
            style="green",
        ),
        justify="center",
    )

    # System information
    system_panel = Panel(
        get_system_info(),
        border_style="bright_black",
        padding=(1, 2),
    )

    console.print(system_panel)

    # Quick start
    quick_start = Panel(
        get_quick_start(),
        title="Quick Start",
        title_align="left",
        border_style="green",
        padding=(1, 2),
    )

    console.print(quick_start)


def func_splash() -> None:
    console.clear()
    
        # Logo
    console.print(get_logo(), justify="center")
    
        # Tagline
    console.print(
        Text(
            "Your schema, populated.",
            style="green",
        ),
        justify="center",
    )
    
        # System information
    system_panel = Panel(
        get_system_info(),
        border_style="bright_black",
        padding=(1, 2),
    )
    
    console.print(system_panel)

if __name__ == "__main__":
    print_splash()