"""SeedForge - Database seed generator for JavaScript/TypeScript projects."""

__version__ = "0.1.0"