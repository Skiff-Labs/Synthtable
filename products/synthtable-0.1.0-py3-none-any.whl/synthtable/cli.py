import click

from synthtable import __version__
from synthtable.ui.splash import print_splash, func_splash


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="Synthtable")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Synthtable - Database seed generator for JavaScript/TypeScript projects."""

    if ctx.invoked_subcommand is None:
        print_splash()


@cli.command()
def version() -> None:
    func_splash()




@cli.command()
def init():
    from synthtable.models.init import init_config
    func_splash()
    init_config()




@cli.command()
def generate():
    from synthtable.models.generate import generate_seeds
    func_splash()
    generate_seeds()


@cli.command()
def inspect():
    func_splash()
    print("inspect in dev")
    pass


@cli.command()
def preview():
    func_splash()
    print("preview in dev")
    pass




if __name__ == "__main__":
    cli()