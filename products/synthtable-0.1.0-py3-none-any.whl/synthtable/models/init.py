import json
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt

console = Console()

CONFIG_FILE = Path("synthtable.config.json")

def init_config():
    """Interactive setup for Synthtable."""
    console.print("\n[bold green]🛠️ Synthtable Configuration Setup[/bold green]\n")

    # Prompt for user inputs
    db_url = Prompt.ask("Enter your Database URL / Prisma connection string")
    num_users = Prompt.ask("Default number of dummy users to generate", default="10")
    
    config_data = {
        "database_url": db_url,
        "default_count": int(num_users),
        "prisma_schema": "./prisma/schema.prisma"
    }

    # Save to local directory
    with open(CONFIG_FILE, "w") as f:
        json.dump(config_data, f, indent=4)

    console.print(f"\n[bold green]✓[/bold green] Configuration saved to [bold white]{CONFIG_FILE}[/bold white]!")
    console.print("[dim]Run 'synthtable generate' to start populating your database.[/dim]\n")