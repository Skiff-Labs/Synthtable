import json
import re
import sys
from pathlib import Path
from rich.console import Console

console = Console()
CONFIG_FILE = Path("synthtable.config.json")
PRISMA_SCHEMA_FILE = Path("prisma/schema.prisma")


def load_config() -> dict:
    """Reads and returns the local synthtable.config.json file."""
    if not CONFIG_FILE.exists():
        console.print("[bold red]Error:[/bold red] Faketable is not initialized.")
        console.print("Please run [bold green]faketable init[/bold green] first.\n")
        sys.exit(1)

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        console.print(f"[bold red]Error reading configuration file:[/bold red] {e}")
        sys.exit(1)


def save_config(data: dict) -> None:
    """Saves data to synthtable.config.json."""
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        console.print(f"[bold red]Failed to save configuration:[/bold red] {e}")
        sys.exit(1)


def parse_prisma_models() -> list[str]:
    """
    Parses `prisma/schema.prisma` to extract all model names.
    Returns a list of model names found (e.g., ['User', 'Post', 'Profile']).
    """
    if not PRISMA_SCHEMA_FILE.exists():
        console.print("[bold yellow]Warning:[/bold yellow] No 'prisma/schema.prisma' found in this directory.")
        return []

    models = []
    model_regex = re.compile(r"^model\s+([A-Za-z0-9_]+)\s*\{", re.MULTILINE)

    try:
        with open(PRISMA_SCHEMA_FILE, "r", encoding="utf-8") as f:
            content = f.read()
            models = model_regex.findall(content)
    except Exception as e:
        console.print(f"[bold red]Failed to parse Prisma schema:[/bold red] {e}")

    return models