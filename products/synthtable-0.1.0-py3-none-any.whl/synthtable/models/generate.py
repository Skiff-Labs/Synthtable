import json
import asyncio
from pathlib import Path
from faker import Faker
from rich.console import Console
from rich.progress import track
import psycopg
import re
from synthtable.models.utils import load_config 

fake = Faker()

console = Console()
fake = Faker()
CONFIG_FILE = Path("synthtable.config.json")


def generate_seeds(count_override: int = None):
    config = load_config()
    db_url = config.get("database_url")
    user_count = count_override or config.get("default_count", 10)

    if not db_url:
        console.print("[bold red]Error:[/bold red] Database URL missing in seedforge.config.json")
        return

    console.print("[yellow]🔌 Connecting directly to database...[/yellow]")

    try:
        with psycopg.connect(db_url) as conn:
            with conn.cursor() as cur:
                console.print(f"[green]🔨 Forging {user_count} dummy users with better-auth accounts...[/green]\n")

                for _ in track(range(user_count), description="Seeding Users..."):
                    user_id = fake.uuid4()
                    name = fake.name()
                    email = fake.unique.email()

                    # 1. Insert into 'user' table (mapped by @@map("user"))
                    cur.execute(
                        """
                        INSERT INTO "user" (id, name, email, "emailVerified", "createdAt", "updatedAt", role)
                        VALUES (%s, %s, %s, %s, NOW(), NOW(), %s::"AppRole");
                        """,
                        (user_id, name, email, True, "client")
                    )

                    # 2. Insert into 'account' table for better-auth credentials
                    cur.execute(
                        """
                        INSERT INTO "account" (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
                        VALUES (%s, %s, 'credential', %s, %s, NOW(), NOW());
                        """,
                        (fake.uuid4(), email, user_id, fake.password(length=12))
                    )

                conn.commit()

        console.print(f"\n[bold green]✓ Successfully seeded {user_count} users & accounts into the database![/bold green]")

    except Exception as e:
        console.print(f"\n[bold red]Database Error:[/bold red] {e}")